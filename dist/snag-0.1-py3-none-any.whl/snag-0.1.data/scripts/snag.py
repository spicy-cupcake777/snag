#!python

from requests import get
from bottle import *

def S(code):
    pass
