# snag

A simple Python project to make accessing HTML elements easier; really more of an experiment than a full-fledged project.
